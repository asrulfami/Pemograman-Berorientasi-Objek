module OOP_01_Minggu03 {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
	requires java.desktop;
	
	opens sisforumahsakit to javafx.graphics, javafx.fxml;
}
