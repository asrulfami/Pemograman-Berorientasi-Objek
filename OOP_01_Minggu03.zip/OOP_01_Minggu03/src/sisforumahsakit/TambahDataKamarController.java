package sisforumahsakit;

import javax.swing.JOptionPane;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

public class TambahDataKamarController {

    @FXML
    private Button btnRekamDataKamar;

    @FXML
    private ChoiceBox<String> cmbJenisKelamin;

    @FXML
    private Spinner<Integer> spinKapasitas;

    @FXML
    private TextField txtNamaKamar;
    
    @FXML
    void handleClickBtnRekamDataKamar(MouseEvent event) {
    	String dataKamar = "";
    	dataKamar += String.format("Nama Kamar: %s" +
    	"\nJenis Kelamin: %s" +
    	"\nKapasitas: %s",
    	txtNamaKamar.getText(),
    	cmbJenisKelamin.getSelectionModel().getSelectedItem(),
    	spinKapasitas.getValue());
    	
    	JOptionPane.showMessageDialog(null, dataKamar);
    }
    
public void initialize() {
	/*
	 Memberi Nilai 2, "Laki-Laki" dan "Perempuan" ke dalam choicebox
	 */
	cmbJenisKelamin.setItems(FXCollections.observableArrayList("Pria","Wanita"));
	//Memilih Index 0 dalam array sebagai default
	cmbJenisKelamin.getSelectionModel().select(0);
	
	/*
	 * Menentukan nilai Minimum = 1, Maksimum = 8, step = 1
	 */
	SpinnerValueFactory<Integer> valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(1,8,1);
	
	spinKapasitas.setValueFactory(valueFactory);
	}
}